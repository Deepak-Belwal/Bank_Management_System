#ifndef _MANAGER_
#define _MANAGER_

#include "bank.h"
#include "syntax.h"
#include "verification.h"

void type_S(Bank &);

void type_P(Bank &);

void type_I(Bank &);

void type_E(Bank &);

#endif