#ifndef __CUTOMER_BANK__
#define __CUSTOMER_BANK__
#include "bank.h"
#include "syntax.h"
#include "verification.h"

void type_O(Bank &);

void type_B(Bank &);

void type_D(Bank &);

void type_W(Bank &);

void type_C(Bank &);

void type_A(Bank &);

void type_U(Bank &);

#endif