#ifndef __CUSTOMER_ATM__
#define __CUSTOMER_ATM__
#include "bank.h"
#include "syntax.h"
#include "verification.h"

void ATM_B(Bank &);

void ATM_W(Bank &);

void ATM_F(Bank &);

void ATM_M(Bank &);

void ATM_X(Bank &);

#endif