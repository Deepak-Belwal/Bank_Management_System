#ifndef __SYNTAX__
#define __SYNTAX__
#include <iostream>

bool passwordCheck(std::string);

bool checkPIN(std::string);

bool checkAmount(double);

bool checkInterest(double);

void passwordpolicy();

void INFO(bool);

#endif