#ifndef _FUNCTION_
#define _FUNCTION_

#include "classes/manager.h"
#include "classes/customer_atm.h"
#include "classes/customer_bank.h"
using namespace std;

void interaction(Bank &, char);

void ATMInteraction(Bank &, char);

#endif